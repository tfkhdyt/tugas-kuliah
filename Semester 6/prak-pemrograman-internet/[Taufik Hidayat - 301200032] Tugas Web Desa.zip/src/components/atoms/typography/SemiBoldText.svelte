<p class="text-lg font-semibold">
	<slot />
</p>
