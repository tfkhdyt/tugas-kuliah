<p class="text-sm md:text-base lg:text-lg">
	<slot />
</p>
