<h3 class="mb-1 text-2xl font-bold">
	<slot />
</h3>
