<h1 class="text-3xl font-bold md:text-5xl md:leading-snug lg:text-6xl lg:leading-snug">
	<slot />
</h1>
