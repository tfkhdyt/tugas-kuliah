<h2 class="text-2xl font-medium lg:text-3xl">
	<slot />
</h2>
