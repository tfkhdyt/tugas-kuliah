<div
	class="leading-relaxed text-gray-600 md:text-lg md:leading-relaxed lg:text-xl lg:leading-relaxed"
>
	<slot />
</div>
