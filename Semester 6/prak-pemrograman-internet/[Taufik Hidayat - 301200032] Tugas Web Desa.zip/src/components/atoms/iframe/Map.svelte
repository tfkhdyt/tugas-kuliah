<iframe
	src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15839.656680068401!2d107.63646531276136!3d-7.019374837715142!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e68ea1821cbbb59%3A0xed1328484545eb5f!2sManggahang%2C%20Kec.%20Baleendah%2C%20Kabupaten%20Bandung%2C%20Jawa%20Barat!5e0!3m2!1sid!2sid!4v1688352191379!5m2!1sid!2sid"
	width="100%"
	height="auto"
	style="border:0;"
	allowfullscreen=""
	loading="lazy"
	referrerpolicy="no-referrer-when-downgrade"
	title="Peta Manggahang"
	class="aspect-video rounded-[2rem] md:rounded-[4rem] lg:aspect-[21/9]"
/>
