<iframe
	width="100%"
	height="auto"
	src="https://www.youtube.com/embed/Yoa0rUk-O9Q"
	title="Panorama KAMPUNG MANGGAHANG Hyperlapse"
	frameborder="0"
	allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
	allowfullscreen
	class="aspect-video rounded-[2rem] md:rounded-[4rem] lg:aspect-[21/9]"
/>
