<script>
	export let src;
	export let alt;
</script>

<img {src} class="h-8" {alt} />
