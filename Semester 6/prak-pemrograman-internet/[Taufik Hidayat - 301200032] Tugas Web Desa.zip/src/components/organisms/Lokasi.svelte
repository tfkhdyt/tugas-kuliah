<script>
	import Map from '../atoms/iframe/Map.svelte';
	import Title from '../atoms/typography/Title.svelte';
</script>

<section
	class="pt-10 pb-20 space-y-8 md:py-20 md:space-y-12 scroll-mt-20 md:scroll-mt-12"
	id="lokasi"
>
	<Title>Lokasi</Title>
	<Map />
</section>
