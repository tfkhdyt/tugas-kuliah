<script>
	import Video from '../atoms/iframe/Video.svelte';
	import Heading from '../molecules/Heading.svelte';
</script>

<section
	class="py-10 space-y-12 md:py-20 md:space-y-14 scroll-mt-20 md:scroll-mt-12"
	id="tentang-kami"
>
	<Heading
		title="Kenali Manggahang dalam 3 menit"
		subtitle="
			Manggahang adalah sebuah kelurahan di kecamatan Baleendah, Bandung, Jawa Barat, Indonesia.
    "
	/>
	<div>
		<Video />
	</div>
</section>
