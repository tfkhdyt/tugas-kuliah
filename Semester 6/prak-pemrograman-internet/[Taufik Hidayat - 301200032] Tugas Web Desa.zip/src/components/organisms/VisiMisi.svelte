<script>
	import VisiMisiContent from '../molecules/VisiMisi/Content.svelte';
	import VisiMisiHeading from '../molecules/VisiMisi/Heading.svelte';
</script>

<section
	class="py-10 space-y-8 md:py-20 lg:space-y-12 scroll-mt-24 md:scroll-mt-18"
	id="visi-misi"
>
	<VisiMisiHeading />
	<VisiMisiContent />
</section>
