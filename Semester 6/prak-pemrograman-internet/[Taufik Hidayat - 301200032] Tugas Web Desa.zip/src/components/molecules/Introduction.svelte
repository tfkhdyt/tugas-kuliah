<script>
	import Subtitle from '../atoms/typography/Subtitle.svelte';
	import Title from '../atoms/typography/Title.svelte';
</script>

<div class="md:max-w-md">
	<Title>Selamat Datang di Manggahang!</Title>
</div>
<div class="md:max-w-md">
	<Subtitle>
		Manggahang adalah sebuah kelurahan di kecamatan Baleendah, Bandung, Jawa Barat,
		Indonesia.
	</Subtitle>
</div>
