<script>
	import Logo from '../atoms/images/Logo.svelte';
	import SemiBoldText from '../atoms/typography/SemiBoldText.svelte';
</script>

<div class="flex items-center space-x-4">
	<Logo src="/img/kab-bandung.svg" alt="Logo Kab. Bandung" />
	<SemiBoldText>Manggahang</SemiBoldText>
</div>
