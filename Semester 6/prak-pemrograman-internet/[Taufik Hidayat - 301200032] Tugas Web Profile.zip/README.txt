Nama         : Taufik Hidayat
NIM          : 301200032
Prodi        : Teknik Informatika
Mata kuliah  : Praktikum Pemrograman Internet

Nama project : Landing page Netflix
Live demo    : https://netflix-tfkhdyt.vercel.app
Source code  : https://github.com/tfkhdyt/netflix-clone
