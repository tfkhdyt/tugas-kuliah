# Encapsulation dalam PHP

## Demo
[https://encapsulation-tfkhdyt.herokuapp.com](https://encapsulation-tfkhdyt.herokuapp.com)

## Screenshots

### Input Data
![Input data](asset/images/input-data.jpg)

### Tampil Data
![Tampil data](asset/images/tampil-data.jpg)

### Jika masuk ke dalam halaman tampil data tanpa input data terlebih dahulu
![Gagal input data](asset/images/input-data-gagal.jpg)