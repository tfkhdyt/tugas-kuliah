package UTSInheritancePolymorphism;

public class Laptop extends Komputer {
    public Laptop(String merk) {
      super(merk);
    }
}
