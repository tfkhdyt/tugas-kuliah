package UTSInheritancePolymorphism;

public class Komputer {
    private String merk;
    public Komputer(String merk) {
      this.merk = merk;
    }
    public String getMerk() {
      return this.merk;
    }
}
