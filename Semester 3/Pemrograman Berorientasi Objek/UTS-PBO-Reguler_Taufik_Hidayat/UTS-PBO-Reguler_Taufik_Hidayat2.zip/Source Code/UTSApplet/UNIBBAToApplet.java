import java.applet.Applet;
import java.awt.Graphics;

public class UNIBBAToApplet extends Applet {
  public void paint (Graphics g) {
    g.drawString("UNIBBA to Applet", 100, 100);
  }
}