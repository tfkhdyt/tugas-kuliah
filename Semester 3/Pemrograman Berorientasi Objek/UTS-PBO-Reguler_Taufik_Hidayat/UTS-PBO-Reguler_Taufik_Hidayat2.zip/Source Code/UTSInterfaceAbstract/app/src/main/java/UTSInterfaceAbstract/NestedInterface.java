package UTSInterfaceAbstract;

class NestedInterface implements Munculkan.Pesan {
  public void msg(String pesan) {
    System.out.println(pesan);
  }
}
