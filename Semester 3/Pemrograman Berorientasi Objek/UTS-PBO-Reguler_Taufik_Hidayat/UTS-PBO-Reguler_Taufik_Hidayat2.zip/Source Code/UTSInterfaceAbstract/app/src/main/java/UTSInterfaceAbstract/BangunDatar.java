package UTSInterfaceAbstract;

public abstract class BangunDatar {
    public abstract double getKeliling();
}