package UTSInterfaceAbstract;

interface Munculkan {
  interface Pesan {
    void msg(String pesan);
  }
}
