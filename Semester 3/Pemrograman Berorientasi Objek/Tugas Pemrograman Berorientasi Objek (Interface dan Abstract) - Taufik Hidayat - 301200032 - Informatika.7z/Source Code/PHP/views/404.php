<div class="container">
  <div class="row">
    <div class="col col-md-6 m-3 mx-md-0">
      <h1 class="title">404 Not Found</h1>
      <div class="row mt-3">
        <div class="col">
          <a class="btn btn-primary btn-sm" href="/?interface"><i class="fas fa-chevron-left"></i> Kembali</a>
        </div>
      </div>
    </div>
  </div>
</div>