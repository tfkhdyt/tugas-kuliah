package Abstract;

public abstract class BangunRuang {
  public abstract double getVolume();
}
