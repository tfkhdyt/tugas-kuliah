Nama : Taufik Hidayat
NIM : 301200032
Prodi : Teknik Informatika (Pagi)
Mata Kuliah : Praktikum Pengantar Pemrograman

Untuk melihat hasil dari program ini, bapak bisa kunjungi website ini:
https://project.tfkhdyt.my.id/data-tanaman

Username: taufik
Password: hidayat
